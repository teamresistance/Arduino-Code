Unzip this folder to:
(Arduino sketchbook folder)\libraries
, then restart Arduino.

Extends the LiquidCrystal library.
